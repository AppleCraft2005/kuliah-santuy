package com.android.modul5.presentation.screens

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun FavouriteMovieScreen() {
    Text("ini halaman film favorit")
}